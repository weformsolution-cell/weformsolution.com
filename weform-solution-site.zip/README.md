# Weform Solution - Next.js Starter

## How to run locally

1. Install dependencies
```bash
npm install
```

2. Run dev server
```bash
npm run dev
```

3. Build for production
```bash
npm run build
npm run start
```

## Deploy to Vercel
Push the repository to GitHub and import the repo in Vercel. Vercel auto-detects Next.js projects.


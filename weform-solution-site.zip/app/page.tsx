'use client'
import React from 'react'
import Image from 'next/image'

export default function HomePage(): JSX.Element {
  return (
    <main className="min-h-screen bg-[#0E1A2B] text-gray-100">
      <header className="container mx-auto flex items-center justify-between py-6 px-6">
        <div className="flex items-center gap-3">
          <Image src="/weform-logo.png" alt="Weform Solution" width={160} height={40} className="h-10 w-auto object-contain" />
          <span className="font-semibold text-lg">Weform Solution</span>
        </div>

        <nav className="hidden md:flex items-center gap-8 text-sm font-medium">
          <a href="#features" className="hover:underline">Services</a>
          <a href="#products" className="hover:underline">Products</a>
          <a href="/blog" className="hover:underline">Blog</a>
          <a href="#contact" className="hover:underline">Contact</a>
          <a href="https://admin.WeformSolution.com" className="ml-4 inline-block rounded-md bg-[#2F80ED] px-4 py-2 text-white">Login</a>
        </nav>

        <button className="md:hidden text-gray-300" aria-label="Open menu">☰</button>
      </header>

      <section className="container mx-auto px-6 py-16 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div>
          <p className="text-sm text-[#8EA3B3] mb-4 tracking-wide">THE COOLEST, SAAS PRODUCT YOU HAVE EVER SEEN</p>
          <h1 className="text-5xl md:text-6xl font-extrabold leading-tight text-white">Make your business faster with Weform Solution</h1>
          <p className="mt-6 text-lg text-[#B7CAD6] max-w-xl">We provide world-class Website Design & Development, SMS, WhatsApp Business API and Voice Call services to help businesses communicate and convert better online.</p>

          <div className="mt-8 flex items-center gap-4">
            <a href="#contact" className="inline-flex items-center gap-3 rounded-md bg-[#2F80ED] px-6 py-3 text-white font-semibold">Get Started</a>
            <a href="#features" className="text-sm text-[#B7CAD6] hover:underline">Explore Services →</a>
          </div>
        </div>

        <div className="flex justify-center md:justify-end">
          <div className="relative w-80 h-80 bg-gradient-to-br from-[#0E293F] to-[#092033] rounded-2xl flex items-center justify-center shadow-2xl">
            <Image src="/illustration-laptop.svg" alt="illustration" width={320} height={320} className="w-64 h-64 object-contain" />
          </div>
        </div>
      </section>

      <section id="features" className="container mx-auto px-6 py-12">
        <h2 className="text-2xl font-bold text-white mb-6">Services we offer</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <ServiceCard title="Website Design & Development" desc="Modern, responsive websites built with Next.js and Tailwind CSS. SEO optimized and fast loading." />
          <ServiceCard title="Bulk SMS Service" desc="Reliable transactional and promotional SMS solutions with high delivery rates." />
          <ServiceCard title="WhatsApp Business API" desc="Official WhatsApp API integration for customer messaging and notifications." />
          <ServiceCard title="Voice Call / IVR" desc="Automated voice calls and IVR systems for reminders, notifications and campaigns." />
          <ServiceCard title="Graphic Design" desc="Branding, posters, social media creatives and print-ready designs." />
          <ServiceCard title="Logo Design" desc="Memorable brand logos & identity systems for businesses of all sizes." />
        </div>
      </section>

      <section className="container mx-auto px-6 py-12">
        <h2 className="text-2xl font-bold text-white mb-6">From our blog</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <BlogCard title="How SMS can boost your sales" excerpt="Short guide on SMS campaigns and conversion tips." />
          <BlogCard title="Why WhatsApp Business API matters" excerpt="How to use WhatsApp for customer engagement at scale." />
          <BlogCard title="Designing fast websites with Next.js" excerpt="Best practices for speed, SEO and UX using Next.js." />
        </div>
      </section>

      <footer id="contact" className="container mx-auto px-6 py-12 border-t border-[#123244]">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <Image src="/weform-logo.png" alt="Weform" width={160} height={40} className="h-10 mb-3 object-contain" />
            <p className="text-[#B7CAD6] max-w-md">Weform Solution — SMS, WhatsApp API, Voice & Web solutions to grow business.</p>
          </div>

          <div>
            <h3 className="font-semibold text-white mb-3">Services</h3>
            <ul className="text-[#9FB6C6] space-y-2">
              <li>Website Design & Development</li>
              <li>Bulk SMS Service</li>
              <li>WhatsApp Business API</li>
              <li>Voice Call / IVR</li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-white mb-3">Contact</h3>
            <p className="text-[#9FB6C6]">Email: hello@weformsolution.com</p>
            <p className="text-[#9FB6C6] mt-2">Phone: +91 90000 00000</p>
            <form className="mt-4 flex flex-col gap-3 max-w-sm" onSubmit={(e)=>e.preventDefault()}>
              <input name="email" className="rounded-md px-3 py-2 bg-[#0A2A3B] border border-[#123244]" placeholder="Your email" />
              <textarea name="message" className="rounded-md px-3 py-2 bg-[#0A2A3B] border border-[#123244]" placeholder="Message" rows={3} />
              <button type="submit" className="rounded-md bg-[#2F80ED] px-4 py-2 font-semibold">Send</button>
            </form>
          </div>
        </div>

        <p className="text-center text-sm text-[#7EA0B6] mt-10">© {new Date().getFullYear()} Weform Solution. All rights reserved.</p>
      </footer>
    </main>
  )
}

function ServiceCard({ title, desc }: { title: string, desc: string }) {
  return (
    <div className="rounded-lg bg-[#0C2A3A] p-6 border border-[#123244] shadow-sm">
      <h4 className="font-semibold text-white mb-2">{title}</h4>
      <p className="text-[#9FB6C6] text-sm">{desc}</p>
      <a className="mt-4 inline-block text-sm text-[#2F80ED]">Learn more →</a>
    </div>
  )
}

function BlogCard({ title, excerpt }: { title: string, excerpt: string }) {
  return (
    <article className="rounded-lg bg-[#0C2A3A] p-6 border border-[#123244]">
      <h4 className="font-semibold text-white mb-2">{title}</h4>
      <p className="text-[#9FB6C6] text-sm">{excerpt}</p>
      <a className="mt-4 inline-block text-sm text-[#2F80ED]">Read →</a>
    </article>
  )
}
